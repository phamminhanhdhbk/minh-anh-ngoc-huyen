<?php
$model = $model ?? null;
$title = $title ?? ($model ? $model->getMetaTitle() : setting('site_name', 'Shop VO'));
$description = $description ?? ($model ? $model->getMetaDescription() : setting('site_description', ''));
$keywords = $keywords ?? ($model ? $model->getMetaKeywords() : '');
$ogTitle = $ogTitle ?? ($model ? $model->getOgTitle() : $title);
$ogDescription = $ogDescription ?? ($model ? $model->getOgDescription() : $description);
$ogImage = $ogImage ?? ($model ? $model->getOgImage() : null);
$canonical = $canonical ?? ($model && method_exists($model, 'getCanonicalUrl') ? $model->getCanonicalUrl() : url()->current());
$schema = $schema ?? ($model ? $model->getSchemaMarkup() : null);
?>

<!-- SEO Meta Tags -->
<title><?php echo e($title); ?></title>
<meta name="description" content="<?php echo e($description); ?>">
<?php if($keywords): ?>
<meta name="keywords" content="<?php echo e($keywords); ?>">
<?php endif; ?>
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo e($canonical); ?>">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="<?php echo e($ogType ?? ($model && get_class($model) === 'App\Product' ? 'product' : 'website')); ?>">
<meta property="og:url" content="<?php echo e($canonical); ?>">
<meta property="og:title" content="<?php echo e($ogTitle); ?>">
<meta property="og:description" content="<?php echo e($ogDescription); ?>">
<?php if($ogImage): ?>
<meta property="og:image" content="<?php echo e($ogImage); ?>">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<?php endif; ?>
<meta property="og:site_name" content="<?php echo e(setting('site_name', 'Shop VO')); ?>">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e($canonical); ?>">
<meta property="twitter:title" content="<?php echo e($ogTitle); ?>">
<meta property="twitter:description" content="<?php echo e($ogDescription); ?>">
<?php if($ogImage): ?>
<meta property="twitter:image" content="<?php echo e($ogImage); ?>">
<?php endif; ?>

<?php if($schema): ?>
<!-- Schema.org markup -->
<script type="application/ld+json">
<?php echo $schema; ?>

</script>
<?php endif; ?>

<!-- Additional SEO meta tags -->
<meta name="author" content="<?php echo e(setting('site_name', 'Shop VO')); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="UTF-8">

<?php if($model && get_class($model) === 'App\Product'): ?>
<!-- Product specific meta -->
<meta property="product:price:amount" content="<?php echo e($model->price); ?>">
<meta property="product:price:currency" content="VND">
<meta property="product:availability" content="<?php echo e($model->stock > 0 ? 'in stock' : 'out of stock'); ?>">
<?php if($model->category): ?>
<meta property="product:category" content="<?php echo e($model->category->name); ?>">
<?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/components/seo-meta.blade.php ENDPATH**/ ?>