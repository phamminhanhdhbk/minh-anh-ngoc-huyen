<?php $__env->startSection('title', 'Quản lý Danh mục - Admin Panel'); ?>
<?php $__env->startSection('page-title', 'Quản lý Danh mục'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">Danh sách Danh mục</h4>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus me-2"></i>Thêm Danh mục
    </a>
</div>

<div class="card">
    <div class="card-body">
        <?php if($categories->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Tên danh mục</th>
                            <th>Slug</th>
                            <th>Số sản phẩm</th>
                            <th>Trạng thái</th>
                            <th>Ngày tạo</th>
                            <th width="120">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><strong><?php echo e($category->id); ?></strong></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php if($category->image): ?>
                                        <img src="<?php echo e($category->image); ?>" alt="<?php echo e($category->name); ?>"
                                             class="rounded me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                    <?php endif; ?>
                                    <div>
                                        <strong><?php echo e($category->name); ?></strong>
                                        <?php if($category->description): ?>
                                            <br><small class="text-muted"><?php echo e(Str::limit($category->description, 50)); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td><code><?php echo e($category->slug); ?></code></td>
                            <td>
                                <span class="badge bg-info"><?php echo e($category->products_count ?? $category->products()->count()); ?></span>
                            </td>
                            <td>
                                <?php if($category->status): ?>
                                    <span class="badge bg-success">Hoạt động</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Tạm dừng</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($category->created_at->format('d/m/Y')); ?></td>
                            <td class="table-actions">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.categories.show', $category)); ?>"
                                       class="btn btn-outline-info" title="Xem chi tiết">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.categories.edit', $category)); ?>"
                                       class="btn btn-outline-warning" title="Chỉnh sửa">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form class="d-inline" action="<?php echo e(route('admin.categories.destroy', $category)); ?>"
                                          method="POST" onsubmit="return confirmDelete('Bạn có chắc muốn xóa danh mục này?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger" title="Xóa">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center mt-3">
                <?php echo e($categories->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-folder-open fa-5x text-muted mb-3"></i>
                <h5>Chưa có danh mục nào</h5>
                <p class="text-muted">Hãy tạo danh mục đầu tiên cho cửa hàng của bạn</p>
                <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Tạo Danh mục
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>