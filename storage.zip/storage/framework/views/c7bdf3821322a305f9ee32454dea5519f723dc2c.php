<?php $__env->startSection('title', 'Dashboard - Admin Panel'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <!-- Statistics Cards -->
    <div class="col-md-6 col-lg-3 mb-3">
        <div class="card stats-card">
            <div class="card-body d-flex align-items-center">
                <div class="stats-icon bg-primary me-3">
                    <i class="fas fa-users"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Tổng Users</h6>
                    <h4 class="mb-0"><?php echo e(number_format($stats['total_users'])); ?></h4>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-3 mb-3">
        <div class="card stats-card">
            <div class="card-body d-flex align-items-center">
                <div class="stats-icon bg-success me-3">
                    <i class="fas fa-box"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Tổng Sản phẩm</h6>
                    <h4 class="mb-0"><?php echo e(number_format($stats['total_products'])); ?></h4>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-3 mb-3">
        <div class="card stats-card">
            <div class="card-body d-flex align-items-center">
                <div class="stats-icon bg-warning me-3">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Tổng Đơn hàng</h6>
                    <h4 class="mb-0"><?php echo e(number_format($stats['total_orders'])); ?></h4>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-3 mb-3">
        <div class="card stats-card">
            <div class="card-body d-flex align-items-center">
                <div class="stats-icon bg-info me-3">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Tổng Doanh thu</h6>
                    <h4 class="mb-0"><?php echo e(number_format($stats['total_revenue'])); ?>đ</h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Recent Orders -->
    <div class="col-lg-8 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-clock me-2"></i>Đơn hàng gần đây</h5>
                <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-sm btn-outline-primary">Xem tất cả</a>
            </div>
            <div class="card-body p-0">
                <?php if($recent_orders->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Mã đơn</th>
                                    <th>Khách hàng</th>
                                    <th>Tổng tiền</th>
                                    <th>Trạng thái</th>
                                    <th>Ngày tạo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $recent_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><strong><?php echo e($order->order_number); ?></strong></td>
                                    <td><?php echo e($order->customer_name); ?></td>
                                    <td><span class="text-success"><?php echo e(number_format($order->total)); ?>đ</span></td>
                                    <td>
                                        <?php switch($order->status):
                                            case ('pending'): ?>
                                                <span class="badge bg-warning">Chờ xử lý</span>
                                                <?php break; ?>
                                            <?php case ('processing'): ?>
                                                <span class="badge bg-info">Đang xử lý</span>
                                                <?php break; ?>
                                            <?php case ('shipped'): ?>
                                                <span class="badge bg-primary">Đã giao</span>
                                                <?php break; ?>
                                            <?php case ('delivered'): ?>
                                                <span class="badge bg-success">Hoàn thành</span>
                                                <?php break; ?>
                                            <?php case ('cancelled'): ?>
                                                <span class="badge bg-danger">Đã hủy</span>
                                                <?php break; ?>
                                        <?php endswitch; ?>
                                    </td>
                                    <td><?php echo e($order->created_at->format('d/m/Y H:i')); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                        <p class="text-muted">Chưa có đơn hàng nào</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Low Stock Products -->
    <div class="col-lg-4 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Sản phẩm sắp hết</h5>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-sm btn-outline-warning">Xem tất cả</a>
            </div>
            <div class="card-body p-0">
                <?php if($low_stock_products->count() > 0): ?>
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $low_stock_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-1"><?php echo e(Str::limit($product->name, 25)); ?></h6>
                                <small class="text-muted"><?php echo e($product->category->name); ?></small>
                            </div>
                            <span class="badge <?php echo e($product->stock <= 5 ? 'bg-danger' : 'bg-warning'); ?> rounded-pill">
                                <?php echo e($product->stock); ?>

                            </span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                        <p class="text-muted">Tất cả sản phẩm đều có đủ tồn kho</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Thao tác nhanh</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 col-sm-6 mb-3">
                        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary w-100">
                            <i class="fas fa-plus me-2"></i>Thêm Sản phẩm
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-3">
                        <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-success w-100">
                            <i class="fas fa-folder-plus me-2"></i>Thêm Danh mục
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-3">
                        <a href="<?php echo e(route('admin.orders.index', ['status' => 'pending'])); ?>" class="btn btn-warning w-100">
                            <i class="fas fa-clock me-2"></i>Đơn chờ xử lý
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-3">
                        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-info w-100">
                            <i class="fas fa-user-plus me-2"></i>Thêm User
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>