<?php if($reviews->count() > 0): ?>
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="review-item border-bottom py-3 mb-3">
        <div class="d-flex justify-content-between align-items-start mb-2">
            <div class="d-flex align-items-center">
                <div class="user-avatar me-3">
                    <?php if($review->user->avatar): ?>
                    <img src="<?php echo e(asset('storage/' . $review->user->avatar)); ?>"
                         class="rounded-circle"
                         style="width: 40px; height: 40px; object-fit: cover;">
                    <?php else: ?>
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center"
                         style="width: 40px; height: 40px;">
                        <?php echo e(strtoupper(substr($review->user->name, 0, 1))); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div>
                    <h6 class="mb-1"><?php echo e($review->user->name); ?></h6>
                    <div class="d-flex align-items-center">
                        <?php echo $review->stars_html; ?>

                        <?php if($review->verified_purchase): ?>
                        <span class="badge bg-success ms-2 small">Đã mua hàng</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <small class="text-muted"><?php echo e($review->created_at->format('d/m/Y')); ?></small>
        </div>

        <?php if($review->title): ?>
        <h6 class="review-title"><?php echo e($review->title); ?></h6>
        <?php endif; ?>

        <?php if($review->comment): ?>
        <p class="review-comment mb-2"><?php echo e($review->comment); ?></p>
        <?php endif; ?>

        <?php if($review->images): ?>
        <div class="review-images mb-2">
            <?php $__currentLoopData = $review->image_urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e($image); ?>"
                 class="img-thumbnail me-2 mb-2 review-image"
                 style="width: 80px; height: 80px; object-fit: cover; cursor: pointer;"
                 onclick="openImageModal('<?php echo e($image); ?>', <?php echo e($index); ?>, <?php echo e(json_encode($review->image_urls)); ?>)">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <!-- Review Actions -->
        <div class="review-actions">
            <button class="btn btn-sm btn-outline-secondary me-2"
                    onclick="toggleHelpful(<?php echo e($review->id); ?>)"
                    data-review-id="<?php echo e($review->id); ?>">
                <i class="fas fa-thumbs-up me-1"></i>
                <span class="helpful-text">Hữu ích</span>
                <span class="helpful-count">(<?php echo e($review->helpful_count ?? 0); ?>)</span>
            </button>

            <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->id() !== $review->user_id): ?>
            <button class="btn btn-sm btn-outline-secondary"
                    onclick="reportReview(<?php echo e($review->id); ?>)">
                <i class="fas fa-flag me-1"></i>Báo cáo
            </button>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Pagination -->
    <?php if($reviews->hasPages()): ?>
    <div class="d-flex justify-content-center mt-4">
        <nav>
            <ul class="pagination">
                
                <?php if($reviews->onFirstPage()): ?>
                    <li class="page-item disabled"><span class="page-link">‹</span></li>
                <?php else: ?>
                    <li class="page-item"><button class="page-link" onclick="loadMoreReviews(<?php echo e($reviews->currentPage() - 1); ?>)">‹</button></li>
                <?php endif; ?>

                
                <?php for($i = 1; $i <= $reviews->lastPage(); $i++): ?>
                    <?php if($i == $reviews->currentPage()): ?>
                        <li class="page-item active"><span class="page-link"><?php echo e($i); ?></span></li>
                    <?php else: ?>
                        <li class="page-item"><button class="page-link" onclick="loadMoreReviews(<?php echo e($i); ?>)"><?php echo e($i); ?></button></li>
                    <?php endif; ?>
                <?php endfor; ?>

                
                <?php if($reviews->hasMorePages()): ?>
                    <li class="page-item"><button class="page-link" onclick="loadMoreReviews(<?php echo e($reviews->currentPage() + 1); ?>)">›</button></li>
                <?php else: ?>
                    <li class="page-item disabled"><span class="page-link">›</span></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
<?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-star text-muted" style="font-size: 3rem;"></i>
        <h5 class="mt-3 text-muted">Chưa có đánh giá nào</h5>
        <p class="text-muted">Hãy là người đầu tiên đánh giá sản phẩm này!</p>
    </div>
<?php endif; ?>

<!-- Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Hình ảnh đánh giá</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="modalImage" src="" class="img-fluid">
                <div class="mt-3">
                    <button class="btn btn-outline-secondary me-2" onclick="previousImage()">
                        <i class="fas fa-chevron-left"></i> Trước
                    </button>
                    <span id="imageCounter"></span>
                    <button class="btn btn-outline-secondary ms-2" onclick="nextImage()">
                        Sau <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
let currentImageIndex = 0;
let currentImages = [];

function openImageModal(imageSrc, index, images) {
    currentImageIndex = index;
    currentImages = images;

    document.getElementById('modalImage').src = imageSrc;
    updateImageCounter();

    const modal = new bootstrap.Modal(document.getElementById('imageModal'));
    modal.show();
}

function updateImageCounter() {
    document.getElementById('imageCounter').textContent =
        `${currentImageIndex + 1} / ${currentImages.length}`;
}

function previousImage() {
    if (currentImageIndex > 0) {
        currentImageIndex--;
        document.getElementById('modalImage').src = currentImages[currentImageIndex];
        updateImageCounter();
    }
}

function nextImage() {
    if (currentImageIndex < currentImages.length - 1) {
        currentImageIndex++;
        document.getElementById('modalImage').src = currentImages[currentImageIndex];
        updateImageCounter();
    }
}

function toggleHelpful(reviewId) {
    <?php if(auth()->guard()->check()): ?>
    fetch(`/reviews/${reviewId}/helpful`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const button = document.querySelector(`[data-review-id="${reviewId}"]`);
            const countSpan = button.querySelector('.helpful-count');
            const textSpan = button.querySelector('.helpful-text');

            countSpan.textContent = `(${data.count})`;
            textSpan.textContent = data.helpful ? 'Đã hữu ích' : 'Hữu ích';

            if (data.helpful) {
                button.classList.remove('btn-outline-secondary');
                button.classList.add('btn-secondary');
            } else {
                button.classList.remove('btn-secondary');
                button.classList.add('btn-outline-secondary');
            }
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
    <?php else: ?>
    alert('Vui lòng đăng nhập để thực hiện hành động này.');
    <?php endif; ?>
}

function reportReview(reviewId) {
    <?php if(auth()->guard()->check()): ?>
    if (confirm('Bạn có chắc muốn báo cáo đánh giá này?')) {
        fetch(`/reviews/${reviewId}/report`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Đã gửi báo cáo thành công. Chúng tôi sẽ xem xét sớm nhất.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
    <?php else: ?>
    alert('Vui lòng đăng nhập để thực hiện hành động này.');
    <?php endif; ?>
}
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/components/review-list.blade.php ENDPATH**/ ?>