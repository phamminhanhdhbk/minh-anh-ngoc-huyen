<?php $__env->startSection('title', 'Chỉnh sửa Theme: ' . $theme->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800">Chỉnh sửa Theme: <?php echo e($theme->name); ?></h1>
        <a href="<?php echo e(route('admin.themes.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Quay lại
        </a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Có lỗi xảy ra:</strong>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Thông tin Theme</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.themes.update', $theme->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="name">Tên Theme <span class="text-danger">*</span></label>
                            <input type="text"
                                   class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="name"
                                   name="name"
                                   value="<?php echo e(old('name', $theme->name)); ?>"
                                   required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="slug">Slug <span class="text-danger">*</span></label>
                            <input type="text"
                                   class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="slug"
                                   name="slug"
                                   value="<?php echo e(old('slug', $theme->slug)); ?>"
                                   required>
                            <small class="form-text text-muted">Định danh unique cho theme</small>
                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="view_path">View Path <span class="text-danger">*</span></label>
                            <input type="text"
                                   class="form-control <?php $__errorArgs = ['view_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="view_path"
                                   name="view_path"
                                   value="<?php echo e(old('view_path', $theme->view_path)); ?>"
                                   required>
                            <small class="form-text text-muted">Đường dẫn đến blade template (vd: welcome, themes.gradient.home)</small>
                            <?php $__errorArgs = ['view_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="description">Mô tả</label>
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      id="description"
                                      name="description"
                                      rows="3"><?php echo e(old('description', $theme->description)); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="author">Tác giả</label>
                            <input type="text"
                                   class="form-control <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="author"
                                   name="author"
                                   value="<?php echo e(old('author', $theme->author)); ?>">
                            <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="version">Version</label>
                            <input type="text"
                                   class="form-control <?php $__errorArgs = ['version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="version"
                                   name="version"
                                   value="<?php echo e(old('version', $theme->version)); ?>"
                                   placeholder="1.0.0">
                            <?php $__errorArgs = ['version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="thumbnail">Thumbnail</label>
                            <?php if($theme->thumbnail): ?>
                                <div class="mb-2">
                                    <img src="<?php echo e(asset($theme->thumbnail)); ?>"
                                         alt="<?php echo e($theme->name); ?>"
                                         class="img-thumbnail"
                                         style="max-width: 300px;">
                                </div>
                            <?php endif; ?>
                            <input type="file"
                                   class="form-control-file <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="thumbnail"
                                   name="thumbnail"
                                   accept="image/*">
                            <small class="form-text text-muted">Ảnh xem trước theme (JPEG, PNG, JPG, GIF - Max: 2MB)</small>
                            <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="order">Thứ tự</label>
                            <input type="number"
                                   class="form-control <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="order"
                                   name="order"
                                   value="<?php echo e(old('order', $theme->order)); ?>"
                                   min="0">
                            <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <div class="custom-control custom-checkbox">
                                <input type="hidden" name="is_default" value="0">
                                <input type="checkbox"
                                       class="custom-control-input"
                                       id="is_default"
                                       name="is_default"
                                       value="1"
                                       <?php echo e(old('is_default', $theme->is_default) ? 'checked' : ''); ?>>
                                <label class="custom-control-label" for="is_default">
                                    Đặt làm theme mặc định
                                </label>
                                <small class="form-text text-muted">Theme mặc định sẽ được sử dụng khi không có theme nào được kích hoạt</small>
                            </div>
                        </div>

                        <hr>

                        <div class="form-group mb-0">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Cập nhật Theme
                            </button>
                            <a href="<?php echo e(route('admin.themes.index')); ?>" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Hủy
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <!-- Theme Actions -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-info">
                        <i class="fas fa-cog"></i> Hành động
                    </h6>
                </div>
                <div class="card-body">
                    <?php if(!$theme->is_active): ?>
                        <form action="<?php echo e(route('admin.themes.activate', $theme->id)); ?>" method="POST" class="mb-3">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                    class="btn btn-success btn-block"
                                    onclick="return confirm('Bạn có chắc muốn kích hoạt theme này?')">
                                <i class="fas fa-check"></i> Kích hoạt Theme
                            </button>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> Theme đang hoạt động
                        </div>
                    <?php endif; ?>

                    <a href="<?php echo e(route('admin.themes.preview', $theme->id)); ?>"
                       class="btn btn-info btn-block mb-3"
                       target="_blank">
                        <i class="fas fa-eye"></i> Xem trước Theme
                    </a>

                    <?php if(!$theme->is_active && !$theme->is_default): ?>
                        <form action="<?php echo e(route('admin.themes.destroy', $theme->id)); ?>"
                              method="POST"
                              onsubmit="return confirm('Bạn có chắc muốn xóa theme này?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-block">
                                <i class="fas fa-trash"></i> Xóa Theme
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Theme Info -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-info">
                        <i class="fas fa-info-circle"></i> Thông tin Theme
                    </h6>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-borderless mb-0">
                        <tr>
                            <th width="40%">Slug:</th>
                            <td><code><?php echo e($theme->slug); ?></code></td>
                        </tr>
                        <tr>
                            <th>View Path:</th>
                            <td><code><?php echo e($theme->view_path); ?></code></td>
                        </tr>
                        <tr>
                            <th>Version:</th>
                            <td><?php echo e($theme->version); ?></td>
                        </tr>
                        <tr>
                            <th>Author:</th>
                            <td><?php echo e($theme->author ?: 'N/A'); ?></td>
                        </tr>
                        <tr>
                            <th>Status:</th>
                            <td>
                                <?php if($theme->is_active): ?>
                                    <span class="badge badge-success">Đang dùng</span>
                                <?php elseif($theme->is_default): ?>
                                    <span class="badge badge-info">Mặc định</span>
                                <?php else: ?>
                                    <span class="badge badge-secondary">Không dùng</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Tạo lúc:</th>
                            <td><?php echo e($theme->created_at->format('d/m/Y H:i')); ?></td>
                        </tr>
                        <tr>
                            <th>Cập nhật:</th>
                            <td><?php echo e($theme->updated_at->format('d/m/Y H:i')); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Theme Settings -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-sliders-h"></i> Cài đặt Theme
                    </h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.themes.updateSettings', $theme->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <?php
                            $settings = $theme->settings ?? [];
                        ?>

                        <?php if($theme->slug === 'gradient-modern'): ?>
                            <div class="form-group">
                                <label for="primary_color">Primary Color</label>
                                <input type="color"
                                       class="form-control"
                                       id="primary_color"
                                       name="settings[primary_color]"
                                       value="<?php echo e($settings['primary_color'] ?? '#667eea'); ?>">
                            </div>

                            <div class="form-group">
                                <label for="secondary_color">Secondary Color</label>
                                <input type="color"
                                       class="form-control"
                                       id="secondary_color"
                                       name="settings[secondary_color]"
                                       value="<?php echo e($settings['secondary_color'] ?? '#764ba2'); ?>">
                            </div>

                            <div class="form-group">
                                <label for="accent_color">Accent Color</label>
                                <input type="color"
                                       class="form-control"
                                       id="accent_color"
                                       name="settings[accent_color]"
                                       value="<?php echo e($settings['accent_color'] ?? '#f093fb'); ?>">
                            </div>
                        <?php else: ?>
                            <p class="text-muted">Theme này chưa có cài đặt tùy chỉnh.</p>
                        <?php endif; ?>

                        <?php if($theme->slug === 'gradient-modern'): ?>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-save"></i> Lưu cài đặt
                            </button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <!-- Guide -->
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-warning">
                        <i class="fas fa-lightbulb"></i> Hướng dẫn
                    </h6>
                </div>
                <div class="card-body">
                    <ul class="small mb-0 pl-3">
                        <li>View Path phải trỏ đến file blade template hợp lệ</li>
                        <li>Slug phải là duy nhất (unique)</li>
                        <li>Theme mặc định sẽ được dùng khi không có theme nào active</li>
                        <li>Không thể xóa theme đang hoạt động hoặc theme mặc định</li>
                        <li>Dùng "Xem trước" để kiểm tra theme trước khi kích hoạt</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
// Auto generate slug from name
document.getElementById('name').addEventListener('input', function() {
    let name = this.value;
    let slug = name.toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/đ/g, 'd')
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .trim();
    document.getElementById('slug').value = slug;
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/admin/themes/edit.blade.php ENDPATH**/ ?>