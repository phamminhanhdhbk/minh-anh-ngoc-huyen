<?php $__env->startSection('title', 'Quản lý Danh mục Blog'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-3">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2>Quản lý Danh mục Blog</h2>
                <a href="<?php echo e(route('admin.blog-categories.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Thêm Danh mục
                </a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th width="80">ID</th>
                            <th width="100">Hình ảnh</th>
                            <th>Tên danh mục</th>
                            <th>Slug</th>
                            <th width="120">Số bài viết</th>
                            <th width="80">Thứ tự</th>
                            <th width="100">Trạng thái</th>
                            <th width="150">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($category->id); ?></td>
                                <td>
                                    <?php if($category->image): ?>
                                        <img src="<?php echo e(asset($category->image)); ?>" alt="<?php echo e($category->name); ?>" class="img-thumbnail" style="width: 60px; height: 60px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-light d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
                                            <i class="fas fa-image text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?php echo e($category->name); ?></strong>
                                    <?php if($category->description): ?>
                                        <br><small class="text-muted"><?php echo e(Str::limit($category->description, 50)); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><code><?php echo e($category->slug); ?></code></td>
                                <td class="text-center">
                                    <span class="badge badge-info"><?php echo e($category->posts_count ?? 0); ?> bài</span>
                                </td>
                                <td class="text-center"><?php echo e($category->order); ?></td>
                                <td>
                                    <?php if($category->status): ?>
                                        <span class="badge badge-success">Hiển thị</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">Ẩn</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.blog-categories.edit', $category->id)); ?>" class="btn btn-sm btn-info" title="Chỉnh sửa">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.blog-categories.destroy', $category->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Bạn có chắc muốn xóa danh mục này?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" title="Xóa">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">Chưa có danh mục nào</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <?php echo e($categories->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/admin/blog-categories/index.blade.php ENDPATH**/ ?>