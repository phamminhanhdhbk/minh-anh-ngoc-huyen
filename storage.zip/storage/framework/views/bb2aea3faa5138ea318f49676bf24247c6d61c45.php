<?php $__env->startSection('title', 'Quản lý Bình luận'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h2 class="mb-4">Quản lý Bình luận</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert">&times;</button>
        </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h6>Tổng bình luận</h6>
                    <h3><?php echo e($totalComments); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h6>Chờ duyệt</h6>
                    <h3><?php echo e($pendingComments); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h6>Đã duyệt</h6>
                    <h3><?php echo e($approvedComments); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <h6>Bị từ chối</h6>
                    <h3><?php echo e($rejectedComments); ?></h3>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-3">
        <div class="card-body">
            <form action="<?php echo e(route('admin.post-comments.index')); ?>" method="GET" class="form-inline">
                <select name="status" class="form-control mr-2">
                    <option value="">-- Trạng thái --</option>
                    <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Chờ duyệt</option>
                    <option value="approved" <?php echo e(request('status') == 'approved' ? 'selected' : ''); ?>>Đã duyệt</option>
                    <option value="rejected" <?php echo e(request('status') == 'rejected' ? 'selected' : ''); ?>>Từ chối</option>
                </select>
                <select name="post" class="form-control mr-2">
                    <option value="">-- Bài viết --</option>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($post->id); ?>" <?php echo e(request('post') == $post->id ? 'selected' : ''); ?>>
                            <?php echo e($post->title); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="btn btn-primary mr-2">
                    <i class="fas fa-search"></i> Lọc
                </button>
                <a href="<?php echo e(route('admin.post-comments.index')); ?>" class="btn btn-secondary">Làm mới</a>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="thead-light">
                        <tr>
                            <th width="80">ID</th>
                            <th>Bài viết</th>
                            <th>Người gửi</th>
                            <th>Nội dung</th>
                            <th width="100">Trạng thái</th>
                            <th width="120">Ngày gửi</th>
                            <th width="180">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($comment->id); ?></td>
                                <td>
                                    <a href="<?php echo e(route('blog.show', $comment->post->slug)); ?>" target="_blank">
                                        <?php echo e(Str::limit($comment->post->title, 40)); ?>

                                    </a>
                                </td>
                                <td>
                                    <strong><?php echo e($comment->name); ?></strong><br>
                                    <small><?php echo e($comment->email); ?></small>
                                </td>
                                <td><?php echo e(Str::limit($comment->content, 80)); ?></td>
                                <td>
                                    <?php if($comment->status == 'pending'): ?>
                                        <span class="badge badge-warning">Chờ duyệt</span>
                                    <?php elseif($comment->status == 'approved'): ?>
                                        <span class="badge badge-success">Đã duyệt</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Từ chối</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($comment->created_at->format('d/m/Y H:i')); ?></td>
                                <td>
                                    <?php if($comment->status != 'approved'): ?>
                                        <form action="<?php echo e(route('admin.post-comments.approve', $comment->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn btn-sm btn-success" title="Duyệt">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if($comment->status != 'rejected'): ?>
                                        <form action="<?php echo e(route('admin.post-comments.reject', $comment->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn btn-sm btn-warning" title="Từ chối">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <form action="<?php echo e(route('admin.post-comments.destroy', $comment->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Xóa bình luận?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" title="Xóa">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">Chưa có bình luận nào</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <?php echo e($comments->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/admin/post-comments/index.blade.php ENDPATH**/ ?>