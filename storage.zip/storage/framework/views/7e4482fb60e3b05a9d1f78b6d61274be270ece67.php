<?php $__env->startSection('title', 'Quản lý Bài viết'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-3">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2>Quản lý Bài viết</h2>
                <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Thêm Bài viết
                </a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Tổng bài viết</h6>
                            <h3 class="mb-0 mt-2"><?php echo e($totalPosts); ?></h3>
                        </div>
                        <i class="fas fa-file-alt fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Đã xuất bản</h6>
                            <h3 class="mb-0 mt-2"><?php echo e($publishedPosts); ?></h3>
                        </div>
                        <i class="fas fa-check-circle fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Bản nháp</h6>
                            <h3 class="mb-0 mt-2"><?php echo e($draftPosts); ?></h3>
                        </div>
                        <i class="fas fa-edit fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-secondary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Đã lưu trữ</h6>
                            <h3 class="mb-0 mt-2"><?php echo e($archivedPosts); ?></h3>
                        </div>
                        <i class="fas fa-archive fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-3">
        <div class="card-body">
            <form action="<?php echo e(route('admin.posts.index')); ?>" method="GET" class="form-inline">
                <div class="form-group mr-2 mb-2">
                    <input type="text" class="form-control" name="search" placeholder="Tìm kiếm..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="form-group mr-2 mb-2">
                    <select name="status" class="form-control">
                        <option value="">-- Trạng thái --</option>
                        <option value="draft" <?php echo e(request('status') == 'draft' ? 'selected' : ''); ?>>Bản nháp</option>
                        <option value="published" <?php echo e(request('status') == 'published' ? 'selected' : ''); ?>>Đã xuất bản</option>
                        <option value="archived" <?php echo e(request('status') == 'archived' ? 'selected' : ''); ?>>Lưu trữ</option>
                    </select>
                </div>
                <div class="form-group mr-2 mb-2">
                    <select name="category" class="form-control">
                        <option value="">-- Danh mục --</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary mr-2 mb-2">
                    <i class="fas fa-search"></i> Lọc
                </button>
                <a href="<?php echo e(route('admin.posts.index')); ?>" class="btn btn-secondary mb-2">
                    <i class="fas fa-redo"></i> Làm mới
                </a>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th width="80">ID</th>
                            <th width="100">Ảnh</th>
                            <th>Tiêu đề</th>
                            <th width="150">Danh mục</th>
                            <th width="120">Tác giả</th>
                            <th width="100">Lượt xem</th>
                            <th width="100">Trạng thái</th>
                            <th width="120">Ngày xuất bản</th>
                            <th width="150">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($post->id); ?></td>
                                <td>
                                    <?php if($post->featured_image): ?>
                                        <img src="<?php echo e(asset($post->featured_image)); ?>" alt="<?php echo e($post->title); ?>" class="img-thumbnail" style="width: 80px; height: 60px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-light d-flex align-items-center justify-content-center" style="width: 80px; height: 60px;">
                                            <i class="fas fa-image text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?php echo e($post->title); ?></strong>
                                    <?php if($post->featured): ?>
                                        <span class="badge badge-warning ml-1"><i class="fas fa-star"></i> Nổi bật</span>
                                    <?php endif; ?>
                                    <?php if($post->excerpt): ?>
                                        <br><small class="text-muted"><?php echo e(Str::limit($post->excerpt, 80)); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($post->category->name ?? 'N/A'); ?></td>
                                <td><?php echo e($post->author->name ?? 'N/A'); ?></td>
                                <td class="text-center">
                                    <span class="badge badge-info"><?php echo e($post->views); ?></span>
                                </td>
                                <td>
                                    <?php if($post->status == 'published'): ?>
                                        <span class="badge badge-success">Đã xuất bản</span>
                                    <?php elseif($post->status == 'draft'): ?>
                                        <span class="badge badge-warning">Bản nháp</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">Lưu trữ</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($post->published_at): ?>
                                        <?php echo e($post->published_at->format('d/m/Y')); ?>

                                        <br><small class="text-muted"><?php echo e($post->published_at->format('H:i')); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">--</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('blog.show', $post->slug)); ?>" target="_blank" class="btn btn-sm btn-secondary" title="Xem">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="btn btn-sm btn-info" title="Chỉnh sửa">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Bạn có chắc muốn xóa bài viết này?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" title="Xóa">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center">Chưa có bài viết nào</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <?php echo e($posts->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>