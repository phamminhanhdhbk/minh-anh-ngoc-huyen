<?php $__env->startSection('title', 'Cấu hình trang web - Admin Panel'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <i class="fas fa-cog me-2"></i>Cấu hình trang web
    </h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <a href="<?php echo e(route('admin.settings.edit')); ?>" class="btn btn-primary">
                <i class="fas fa-edit me-2"></i>Chỉnh sửa
            </a>
        </div>
        <div class="btn-group">
            <form action="<?php echo e(route('admin.settings.reset')); ?>" method="POST" class="d-inline" onsubmit="return confirm('Bạn có chắc muốn khôi phục cấu hình mặc định?')">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-outline-warning">
                    <i class="fas fa-undo me-2"></i>Khôi phục mặc định
                </button>
            </form>
        </div>
    </div>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if($settings->count() > 0): ?>
<div class="row">
    <div class="col-lg-3">
        <!-- Settings Navigation -->
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">Nhóm cấu hình</h6>
            </div>
            <div class="list-group list-group-flush">
                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $groupSettings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="#<?php echo e($group); ?>" class="list-group-item list-group-item-action"
                   onclick="showGroup('<?php echo e($group); ?>')">
                    <i class="fas fa-<?php echo e(getGroupIcon($group)); ?> me-2"></i>
                    <?php echo e(getGroupName($group)); ?>

                    <span class="badge bg-secondary ms-auto"><?php echo e($groupSettings->count()); ?></span>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="col-lg-9">
        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $groupSettings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4 group-section" id="section-<?php echo e($group); ?>" style="<?php echo e($loop->first ? '' : 'display: none;'); ?>">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-<?php echo e(getGroupIcon($group)); ?> me-2"></i>
                    <?php echo e(getGroupName($group)); ?>

                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = $groupSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-4">
                        <div class="setting-item border rounded p-3 h-100">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <label class="fw-bold text-primary"><?php echo e($setting->label); ?></label>
                                <span class="badge bg-light text-dark"><?php echo e(ucfirst($setting->type)); ?></span>
                            </div>

                            <?php if($setting->description): ?>
                            <p class="text-muted small mb-3"><?php echo e($setting->description); ?></p>
                            <?php endif; ?>

                            <div class="setting-value">
                                <?php if($setting->type === 'image'): ?>
                                    <?php if($setting->value): ?>
                                    <img src="<?php echo e($setting->formatted_value); ?>" alt="<?php echo e($setting->label); ?>"
                                         class="img-thumbnail" style="max-height: 100px;">
                                    <?php else: ?>
                                    <div class="bg-light rounded p-3 text-center text-muted">
                                        <i class="fas fa-image fa-2x mb-2"></i>
                                        <p class="mb-0">Chưa có hình ảnh</p>
                                    </div>
                                    <?php endif; ?>
                                <?php elseif($setting->type === 'boolean'): ?>
                                    <span class="badge bg-<?php echo e($setting->value ? 'success' : 'secondary'); ?> fs-6">
                                        <i class="fas fa-<?php echo e($setting->value ? 'check' : 'times'); ?> me-1"></i>
                                        <?php echo e($setting->formatted_value); ?>

                                    </span>
                                <?php elseif($setting->type === 'textarea'): ?>
                                    <div class="bg-light p-2 rounded">
                                        <?php echo nl2br(e($setting->value)); ?>

                                    </div>
                                <?php elseif($setting->type === 'url'): ?>
                                    <?php if($setting->value): ?>
                                    <a href="<?php echo e($setting->value); ?>" target="_blank" class="text-decoration-none">
                                        <?php echo e($setting->value); ?> <i class="fas fa-external-link-alt ms-1"></i>
                                    </a>
                                    <?php else: ?>
                                    <span class="text-muted">Chưa cấu hình</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="fw-semibold"><?php echo e($setting->value ?: 'Chưa cấu hình'); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php else: ?>
<div class="text-center py-5">
    <i class="fas fa-cog fa-3x text-muted mb-3"></i>
    <h4>Chưa có cấu hình nào</h4>
    <p class="text-muted">Hãy tạo cấu hình mặc định để bắt đầu.</p>
    <form action="<?php echo e(route('admin.settings.reset')); ?>" method="POST" class="d-inline">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Tạo cấu hình mặc định
        </button>
    </form>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function showGroup(group) {
    // Hide all sections
    document.querySelectorAll('.group-section').forEach(section => {
        section.style.display = 'none';
    });

    // Show selected section
    document.getElementById('section-' + group).style.display = 'block';

    // Update active nav item
    document.querySelectorAll('.list-group-item').forEach(item => {
        item.classList.remove('active');
    });
    event.target.classList.add('active');
}
</script>
<?php $__env->stopPush(); ?>

<?php
function getGroupIcon($group) {
    $icons = [
        'general' => 'home',
        'contact' => 'phone',
        'social' => 'share-alt',
        'business' => 'business-time'
    ];
    return $icons[$group] ?? 'cog';
}

function getGroupName($group) {
    $names = [
        'general' => 'Thông tin chung',
        'contact' => 'Thông tin liên hệ',
        'social' => 'Mạng xã hội',
        'business' => 'Kinh doanh'
    ];
    return $names[$group] ?? ucfirst($group);
}
?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>