<?php $__env->startSection('title', 'Quản lý đánh giá'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Quản lý đánh giá</h1>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('admin.reviews.index')); ?>" class="text-decoration-none">
                <div class="card border-left-primary shadow h-100 py-2 hover-shadow">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Tổng đánh giá
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['total']); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-star fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('admin.reviews.index', ['status' => 'pending'])); ?>" class="text-decoration-none">
                <div class="card border-left-warning shadow h-100 py-2 hover-shadow">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                    Chờ duyệt
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['pending']); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-clock fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('admin.reviews.index', ['status' => 'approved'])); ?>" class="text-decoration-none">
                <div class="card border-left-success shadow h-100 py-2 hover-shadow">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    Đã duyệt
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['approved']); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('admin.reviews.index', ['status' => 'verified'])); ?>" class="text-decoration-none">
                <div class="card border-left-info shadow h-100 py-2 hover-shadow">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                    Đã mua hàng
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['verified']); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-shield-alt fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <!-- Rating Distribution -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Phân bố đánh giá</h6>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $ratingStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex align-items-center mb-2">
                        <span class="me-3" style="width: 60px;"><?php echo e($rating); ?> sao</span>
                        <div class="progress flex-grow-1 me-3" style="height: 20px;">
                            <div class="progress-bar bg-warning"
                                 style="width: <?php echo e($stats['total'] > 0 ? ($count / $stats['total'] * 100) : 0); ?>%">
                                <?php echo e($count); ?>

                            </div>
                        </div>
                        <span class="text-muted"><?php echo e(number_format($stats['total'] > 0 ? ($count / $stats['total'] * 100) : 0, 1)); ?>%</span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Bộ lọc</h6>
        </div>
        <div class="card-body">
            <form method="GET" id="filterForm">
                <div class="row">
                    <div class="col-md-3">
                        <select name="status" class="form-control" onchange="document.getElementById('filterForm').submit()">
                            <option value="">Tất cả trạng thái</option>
                            <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Chờ duyệt</option>
                            <option value="approved" <?php echo e(request('status') == 'approved' ? 'selected' : ''); ?>>Đã duyệt</option>
                            <option value="verified" <?php echo e(request('status') == 'verified' ? 'selected' : ''); ?>>Đã mua hàng</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="rating" class="form-control" onchange="document.getElementById('filterForm').submit()">
                            <option value="">Tất cả đánh giá</option>
                            <?php for($i = 5; $i >= 1; $i--): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e(request('rating') == $i ? 'selected' : ''); ?>><?php echo e($i); ?> sao</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control"
                                   placeholder="Tìm kiếm đánh giá, sản phẩm, khách hàng..."
                                   value="<?php echo e(request('search')); ?>">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Reviews Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Danh sách đánh giá</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Khách hàng</th>
                            <th>Sản phẩm</th>
                            <th>Đánh giá</th>
                            <th>Nội dung</th>
                            <th>Trạng thái</th>
                            <th>Ngày tạo</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php if($review->user->avatar): ?>
                                    <img src="<?php echo e(asset('storage/' . $review->user->avatar)); ?>"
                                         class="rounded-circle me-2"
                                         style="width: 32px; height: 32px; object-fit: cover;">
                                    <?php else: ?>
                                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2"
                                         style="width: 32px; height: 32px; font-size: 12px;">
                                        <?php echo e(strtoupper(substr($review->user->name, 0, 1))); ?>

                                    </div>
                                    <?php endif; ?>
                                    <div>
                                        <div class="font-weight-bold"><?php echo e($review->user->name); ?></div>
                                        <small class="text-muted"><?php echo e($review->user->email); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <a href="<?php echo e(route('products.show', $review->product)); ?>" target="_blank">
                                    <?php echo e(Str::limit($review->product->name, 30)); ?>

                                </a>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php echo $review->stars_html; ?>

                                    <span class="ms-2 badge bg-warning"><?php echo e($review->rating); ?></span>
                                </div>
                            </td>
                            <td>
                                <?php if($review->title): ?>
                                <strong><?php echo e(Str::limit($review->title, 20)); ?></strong><br>
                                <?php endif; ?>
                                <?php if($review->comment): ?>
                                <small><?php echo e(Str::limit($review->comment, 50)); ?></small>
                                <?php endif; ?>
                                <?php if($review->images): ?>
                                <br><small class="text-info"><i class="fas fa-images"></i> <?php echo e(count($review->image_urls)); ?> ảnh</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($review->approved): ?>
                                <span class="badge bg-success">Đã duyệt</span>
                                <?php else: ?>
                                <span class="badge bg-warning">Chờ duyệt</span>
                                <?php endif; ?>

                                <?php if($review->verified_purchase): ?>
                                <br><span class="badge bg-info mt-1">Đã mua</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($review->created_at->format('d/m/Y H:i')); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('admin.reviews.show', $review)); ?>"
                                       class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>

                                    <?php if(!$review->approved): ?>
                                    <button onclick="approveReview(<?php echo e($review->id); ?>)"
                                            class="btn btn-sm btn-success">
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <?php else: ?>
                                    <button onclick="rejectReview(<?php echo e($review->id); ?>)"
                                            class="btn btn-sm btn-warning">
                                        <i class="fas fa-times"></i>
                                    </button>
                                    <?php endif; ?>

                                    <button onclick="deleteReview(<?php echo e($review->id); ?>)"
                                            class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">Không có đánh giá nào</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if($reviews->hasPages()): ?>
            <div class="d-flex justify-content-center">
                <?php echo e($reviews->appends(request()->query())->links()); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function approveReview(reviewId) {
    if (confirm('Bạn có chắc muốn duyệt đánh giá này?')) {
        fetch(`/admin/reviews/${reviewId}/approve`, {
            method: 'PATCH',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
}

function rejectReview(reviewId) {
    if (confirm('Bạn có chắc muốn từ chối đánh giá này?')) {
        fetch(`/admin/reviews/${reviewId}/reject`, {
            method: 'PATCH',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
}

function deleteReview(reviewId) {
    if (confirm('Bạn có chắc muốn xóa đánh giá này? Hành động này không thể hoàn tác.')) {
        fetch(`/admin/reviews/${reviewId}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/admin/reviews/index.blade.php ENDPATH**/ ?>