<?php $__env->startSection('title', 'Quản lý Sản phẩm - Admin Panel'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <i class="fas fa-box me-2"></i>Quản lý Sản phẩm
    </h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Thêm Sản phẩm
        </a>
    </div>
</div>

<!-- Filter Form -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.products.index')); ?>" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Tìm kiếm</label>
                <input type="text" class="form-control" name="search"
                       value="<?php echo e(request('search')); ?>" placeholder="Tên sản phẩm, SKU...">
            </div>
            <div class="col-md-3">
                <label class="form-label">Danh mục</label>
                <select class="form-select" name="category">
                    <option value="">Tất cả danh mục</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Trạng thái</label>
                <select class="form-select" name="status">
                    <option value="">Tất cả</option>
                    <option value="1" <?php echo e(request('status') === '1' ? 'selected' : ''); ?>>Hoạt động</option>
                    <option value="0" <?php echo e(request('status') === '0' ? 'selected' : ''); ?>>Tạm dừng</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-outline-primary me-2">
                    <i class="fas fa-search"></i>
                </button>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-times"></i>
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Products Table -->
<div class="card">
    <div class="card-body">
        <?php if($products->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Sản phẩm</th>
                            <th>Danh mục</th>
                            <th>Giá</th>
                            <th>Tồn kho</th>
                            <th>Trạng thái</th>
                            <th>Ngày tạo</th>
                            <th width="150">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><strong><?php echo e($product->id); ?></strong></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php if($product->primary_image_url): ?>
                                        <img src="<?php echo e($product->primary_image_url); ?>" alt="<?php echo e($product->name); ?>"
                                             class="rounded me-3" style="width: 50px; height: 50px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-light rounded me-3 d-flex align-items-center justify-content-center"
                                             style="width: 50px; height: 50px;">
                                            <i class="fas fa-image text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <h6 class="mb-0"><?php echo e($product->name); ?></h6>
                                        <?php if($product->sku): ?>
                                            <small class="text-muted">SKU: <?php echo e($product->sku); ?></small>
                                        <?php endif; ?>
                                        <?php if($product->featured): ?>
                                            <span class="badge bg-warning text-dark ms-1">Nổi bật</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo e($product->category->name); ?></span>
                            </td>
                            <td>
                                <?php if($product->sale_price < $product->price): ?>
                                    <div>
                                        <span class="text-decoration-line-through text-muted small"><?php echo e(number_format($product->price)); ?>₫</span>
                                    </div>
                                    <strong class="text-success"><?php echo e(number_format($product->sale_price)); ?>₫</strong>
                                <?php else: ?>
                                    <strong><?php echo e(number_format($product->price)); ?>₫</strong>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($product->stock <= 10): ?>
                                    <span class="badge bg-danger"><?php echo e($product->stock); ?></span>
                                <?php elseif($product->stock <= 50): ?>
                                    <span class="badge bg-warning"><?php echo e($product->stock); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-success"><?php echo e($product->stock); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($product->status): ?>
                                    <span class="badge bg-success">Hoạt động</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Tạm dừng</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($product->created_at->format('d/m/Y')); ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.products.show', $product)); ?>"
                                       class="btn btn-outline-info" title="Xem chi tiết">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.products.edit', $product)); ?>"
                                       class="btn btn-outline-warning" title="Chỉnh sửa">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form class="d-inline" action="<?php echo e(route('admin.products.destroy', $product)); ?>"
                                          method="POST" onsubmit="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger" title="Xóa">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center mt-3">
                <?php echo e($products->appends(request()->query())->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-box-open fa-5x text-muted mb-3"></i>
                <h5>Chưa có sản phẩm nào</h5>
                <p class="text-muted">Hãy thêm sản phẩm đầu tiên cho cửa hàng của bạn</p>
                <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Thêm Sản phẩm
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    console.log('Product search script loaded');

    // Manual submit button
    $('.btn-outline-primary').on('click', function(e) {
        e.preventDefault();
        var form = $(this).closest('form');
        console.log('Search form submitted', {
            search: $('input[name="search"]').val(),
            category: $('select[name="category"]').val(),
            status: $('select[name="status"]').val()
        });
        form.submit();
    });

    // Auto submit form on search input (with longer delay)
    $('input[name="search"]').on('keyup', function() {
        var searchForm = $(this).closest('form');
        var searchValue = $(this).val();

        clearTimeout(window.searchTimeout);
        window.searchTimeout = setTimeout(function() {
            if (searchValue.length >= 2 || searchValue.length === 0) {
                console.log('Auto submitting search:', searchValue);
                searchForm.submit();
            }
        }, 1000);
    });

    // Submit form on select change
    $('select[name="category"], select[name="status"]').on('change', function() {
        console.log('Filter changed:', $(this).attr('name'), $(this).val());
        $(this).closest('form').submit();
    });

    // Clear button functionality
    $('.btn-outline-secondary').on('click', function(e) {
        e.preventDefault();
        console.log('Clear button clicked');
        $('input[name="search"]').val('');
        $('select[name="category"]').val('');
        $('select[name="status"]').val('');
        $(this).closest('form').submit();
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/admin/products/index.blade.php ENDPATH**/ ?>