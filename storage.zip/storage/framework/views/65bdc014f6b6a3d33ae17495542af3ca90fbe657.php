<tr data-item-id="<?php echo e($item->id); ?>" data-level="<?php echo e($level); ?>">
    <td class="text-center">
        <?php if($level == 0): ?>
            <i class="fas fa-grip-vertical drag-handle" style="cursor: move;"></i>
        <?php endif; ?>
    </td>
    <td><?php echo e($item->id); ?></td>
    <td>
        <div style="padding-left: <?php echo e($level * 20); ?>px;">
            <?php if($level > 0): ?>
                <i class="fas fa-level-up-alt fa-rotate-90 text-muted mr-1"></i>
            <?php endif; ?>
            <?php if($item->icon): ?>
                <i class="<?php echo e($item->icon); ?> mr-1"></i>
            <?php endif; ?>
            <strong><?php echo e($item->title); ?></strong>
        </div>
    </td>
    <td>
        <?php if($item->url): ?>
            <a href="<?php echo e($item->url); ?>" target="<?php echo e($item->target); ?>" class="text-primary">
                <small><?php echo e(Str::limit($item->url, 30)); ?></small>
            </a>
        <?php elseif($item->route): ?>
            <code><?php echo e($item->route); ?></code>
        <?php else: ?>
            <span class="text-muted">-</span>
        <?php endif; ?>
    </td>
    <td>
        <?php if($item->icon): ?>
            <i class="<?php echo e($item->icon); ?>"></i>
            <br><small class="text-muted"><?php echo e($item->icon); ?></small>
        <?php else: ?>
            <span class="text-muted">-</span>
        <?php endif; ?>
    </td>
    <td><?php echo e($item->order); ?></td>
    <td>
        <?php if($item->is_active): ?>
            <span class="badge badge-success">Hiện</span>
        <?php else: ?>
            <span class="badge badge-danger">Ẩn</span>
        <?php endif; ?>
    </td>
    <td>
        <div class="btn-group btn-group-sm" role="group">
            <button type="button"
                    class="btn btn-info"
                    onclick="editMenuItem(<?php echo e($item->id); ?>)"
                    title="Chỉnh sửa">
                <i class="fas fa-edit"></i>
            </button>
            <form action="<?php echo e(route('admin.menus.items.destroy', [$menu->id, $item->id])); ?>"
                  method="POST"
                  class="d-inline"
                  onsubmit="return confirm('Bạn có chắc chắn muốn xóa mục menu này?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger" title="Xóa">
                    <i class="fas fa-trash"></i>
                </button>
            </form>
        </div>
    </td>
</tr>

<?php if($item->children->count() > 0): ?>
    <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('admin.menus.partials.menu-item-row', ['item' => $child, 'level' => $level + 1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\ALL-PROJECT\project-vo\laravel-project\resources\views/admin/menus/partials/menu-item-row.blade.php ENDPATH**/ ?>