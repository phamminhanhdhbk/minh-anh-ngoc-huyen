<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Category;
use App\Theme;

class PublicController extends Controller
{
    public function index()
    {
        // Get theme (preview mode or active theme)
        $themeId = session('preview_theme_id');
        $theme = $themeId ? Theme::find($themeId) : Theme::getActiveTheme();

        // Get featured products
        $featuredProducts = Product::with(['category', 'primaryImage'])
            ->where('status', true)
            ->where('featured', true)
            ->limit(8)
            ->get();

        // Get latest products
        $latestProducts = Product::with(['category', 'primaryImage'])
            ->where('status', true)
            ->latest()
            ->limit(12)
            ->get();

        // Get categories with product count
        $categories = Category::with('products')
            ->where('status', true)
            ->withCount(['products' => function($query) {
                $query->where('status', true);
            }])
            ->having('products_count', '>', 0)
            ->limit(6)
            ->get();

        // Get best selling products
        $bestSellers = Product::with(['category', 'primaryImage', 'orderItems'])
            ->where('status', true)
            ->withCount('orderItems')
            ->having('order_items_count', '>', 0)
            ->orderBy('order_items_count', 'desc')
            ->limit(6)
            ->get();

        // Determine which view to render
        $view = $theme && $theme->view_path ? $theme->view_path : 'welcome';

        return view($view, compact('featuredProducts', 'latestProducts', 'categories', 'bestSellers', 'theme'));
    }
}
